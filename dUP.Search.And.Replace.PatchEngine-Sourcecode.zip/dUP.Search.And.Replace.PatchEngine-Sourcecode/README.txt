diablo2oo2's dUP2 SearchAndReplace Patch Engine Sourcecode:

ASM Code 32-bit

[snr_patchengine.asm]

;**********************************************************************************************
;* Example (how to use)                                                                       *
;* ------------------------------------------------------------------------------------------ *
;* search : 2A 45 EB ?? C3 ?? EF                                                              *
;* replace: 2A ?? ?? 10 33 C0 ??                                                              *
;*                                                                                            *
;* .data                                                                                      *
;* SearchPattern   db 02Ah, 045h, 0EBh, 000h, 0C3h, 000h, 0EFh                                *
;* SearchMask      db    0,    0,    0,    1,    0,    1,    0   ;(1=Ignore Byte)             *
;*                                                                                            *
;* ReplacePattern  db 02Ah, 000h, 000h, 010h, 033h, 0C0h, 000h                                *
;* ReplaceMask     db    0,    1,    1,    0,    0,    0,    1   ;(1=Ignore Byte)             *
;*                                                                                            *
;* .const                                                                                     *
;* PatternSize     equ 7                                                                      *
;*                                                                                            *
;* .code                                                                                      *
;* push -1                      ;Replace Number (-1=ALL / 2=2nd match ...)                    *
;* push FileSize                ;how many bytes to search from beginning from TargetAdress    *
;* push PatternSize             ;lenght of Pattern                                            *
;* push offset ReplaceMask                                                                    *
;* push offset ReplacePattern                                                                 *
;* push offset SearchMask                                                                     *
;* push offset SearchPattern                                                                  *
;* push TargetAddress           ;the memory address where the search starts                   *
;* call SearchAndReplace                                                                      *
;*                                                                                            *
;* ReturnValue in eax (1=Success 0=Failed)                                                    *
;**********************************************************************************************

.586                    
.model flat, stdcall
option casemap :none

SearchAndReplace PROTO :DWORD,:DWORD,:DWORD,:DWORD,:DWORD,:DWORD,:DWORD,:DWORD

.code
;----this procedure is only for compiling a dll---
align 16
DllEntry proc _hinstance:DWORD, _reason:DWORD, _reserved1:DWORD
    mov eax,1 ;TRUE
    ret
DllEntry endp


align 16
SearchAndReplace proc   _targetadress:dword,_searchpattern:dword,_searchmask:dword,_replacepattern:dword,
            _replacemask:dword,_patternsize:dword,_searchsize:dword,_patchnumber:dword

    LOCAL local_returnvalue :byte   ;returns if something was patched
    LOCAL local_match   :dword  ;counts how many matches

    pushad
    mov local_returnvalue,0
    mov local_match,0

    mov edi,_targetadress
    mov esi,_searchpattern
    mov edx,_searchmask
    mov ebx,_patternsize
    xor ecx,ecx

    .while ecx!=_searchsize
        @search_again:
        ;---check if pattern exceed memory---
        mov eax,ecx     ;ecx=raw offset
        add eax,ebx     ;raw offset + patternsize
        cmp eax,_searchsize
        ja @return      ;if (raw offset + patternsize) > searchsize then bad!

        push ecx        ;counter
        push esi        ;searchpattern
        push edi        ;targetaddress
        push edx        ;searchmask

        mov ecx,ebx     ;ebx=patternsize
        @cmp_mask:
        test ecx,ecx
        je @pattern_found
        cmp byte ptr[edx],1 ;searchmask
        je @ignore
        lodsb           ;load searchbyte to al & inc esi
        scasb           ;cmp al,targetadressbyte & inc edi
        jne @skip
        inc edx         ;searchmask
        dec ecx         ;patternsize
        jmp @cmp_mask
        @ignore:
        inc edi         ;targetadress
        inc esi         ;searchpattern
        inc edx         ;searchmask
        dec ecx         ;patternsize
        jmp @cmp_mask

        @skip:
        pop edx
        pop edi         ;targetadress
        pop esi         ;searchpattern
        pop ecx

        inc edi         ;targetadress
        inc ecx         ;counter
    .endw
    ;---scanned whole memory size---
    jmp @return 

    @pattern_found:
    inc local_match
    pop edx
    pop edi             ;targetadress
    pop esi
    mov eax,_patchnumber
    cmp eax,-1
    je @replace         
    cmp local_match,eax
    je @replace
    pop ecx             ;counter
    inc edi             ;targetadress
    jmp @search_again

    ;---replace pattern---
    @replace:
    mov esi,_replacepattern
    mov edx,_replacemask

    xor ecx,ecx
    .while ecx!=ebx         ;ebx=patternsize
        @cmp_mask_2:
        cmp byte ptr[edx],1
        je @ignore_2
        lodsb           ;load replacebyte to al from esi & inc esi
        stosb           ;mov byte ptr[edi],al & inc edi
        jmp @nextbyte
        @ignore_2:
        inc edi         ;targetadress
        inc esi         ;replacepattern
        @nextbyte:
        inc edx         ;replacemask
        inc ecx         ;counter
    .endw
    mov local_returnvalue,1     ;yes, something was patched

    ;---search again?---
    pop ecx             ;counter-->scanned size
    cmp _patchnumber,-1
    jne @return
    sub edi,ebx         ;edi=targetadress ; countinue where stopped
    inc edi             ;...
    inc ecx             ;ecx=counter(pointer to offset)  /bug fixed in v2.07
    mov esi,_searchpattern
    mov edx,_searchmask
    jmp @search_again

    ;---return---
    @return:
    popad
    movzx eax,local_returnvalue
    ret
SearchAndReplace endp

; Dao Van Trong - Trong.CF

end DllEntry

[snr_patchengine.def]

LIBRARY snr_patchengine
EXPORTS
SearchAndReplace

Complie:

\masm32\bin\ml /c /coff /Cp snr_patchengine.asm
\masm32\bin\link /dll /DEF:snr_patchengine.def /subsystem:windows /libpath:\masm32\lib snr_patchengine.obj

del *.obj

pause

;::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


AutoIt DllCall Function:

; Example (how to use)
Local $StringToSnR = "5472306E67"
Local $sSearch = "5472??6E67"
Local $sReplace = "54726F6E67"
Local $OUT = _HexSearchAndReplace($StringToSnR, $sSearch, $sReplace)
Local $Error = @error
Local $Extended = @extended

ConsoleWrite(">       IN: " & $StringToSnR & @CRLF)
ConsoleWrite("-      OUT: " & $OUT & @CRLF)
ConsoleWrite("+ Extended: " & $Extended & @CRLF)
ConsoleWrite("!    Error: " & $Error & @CRLF & @CRLF)
MsgBox(0, "", "+        -IN: " & $StringToSnR & @CRLF & "-      OUT: " & $OUT & @CRLF & @CRLF & "+ Extended: " & $Extended & @CRLF & "!          Error: " & $Error & @CRLF)

;eg2:
ConsoleWrite("-      OUT: " & _HexSearchAndReplace("001122330033221100", "00", "99") & @CRLF & "!    Error: " & @error & @CRLF & @CRLF)
; End Example.

; #FUNCTION# ;===============================================================================
; Name...........: _HexSearchAndReplace
; Description ...: Search and Replace Hex data.
; Syntax.........: _HexSearchAndReplace($StringToSnR, $sSearch, $sReplace)
; Parameters ....: $StringToSnR - Hex data to Search and Replace.
;                  $sSearch     - Hex to Search.
;                  $sReplace    - Hex to Replace.
; Return values .: Success - Returns Hex Replaced.
;                          - Sets @extended to Type of Return
;                  Failure - Returns the original string and sets @error to non zero
; Author ........: Danyfirex  and  Dao Van Trong - Trong.CF
;==========================================================================================
Func _HexSearchAndReplace($StringToSnR, $sSearch, $sReplace)
 Local Const $oStringToSnR = $StringToSnR
 Local $tReturn = 0, $IsBinary = 0
 If IsBinary($StringToSnR) Then $IsBinary = 1
 If (StringLeft($StringToSnR, 2) = "0x") Then
  $StringToSnR = StringTrimLeft($StringToSnR, 2)
  $tReturn = 1
 EndIf
 If (StringLeft($sSearch, 2) = "0x") Then $sSearch = StringTrimLeft($sSearch, 2)
 If (StringLeft($sSearch, 2) = "0x") Then $sReplace = StringTrimLeft($sReplace, 2)
 If (StringLen($StringToSnR) = 0) Or (StringLen($sSearch) = 0) Then Return SetError(-1, 0, $oStringToSnR);Not think to replace
 If @AutoItX64 Then Return SetError(1, 0, $StringToSnR);Dll only for 32-bit
 Local $taStrPtr = DllStructCreate("char Data[" & StringLen($StringToSnR) & "]")
 $taStrPtr.Data = $StringToSnR
 Local $spStrPtr = DllStructCreate("byte[" & StringLen($sSearch) & "]")
 Local $smStrPtr = DllStructCreate("byte[" & StringLen($sSearch) & "]")
 Local $aStr = StringSplit($sSearch, "")
 For $i = 1 To $aStr[0]
  DllStructSetData($spStrPtr, 1, Asc($aStr[$i]), $i)
  DllStructSetData($smStrPtr, 1, $aStr[$i] = "?" ? 1 : 0, $i);avoid a
 Next
 Local $rpStrPtr = DllStructCreate("byte[" & StringLen($sReplace) & "]")
 Local $tmStrPtr = DllStructCreate("byte[" & StringLen($sReplace) & "]")
 Local $aStr = StringSplit($sReplace, "")
 For $i = 1 To $aStr[0]
  DllStructSetData($rpStrPtr, 1, Asc($aStr[$i]), $i)
  DllStructSetData($tmStrPtr, 1, $aStr[$i] = "?" ? 1 : 0, $i);avoid b
 Next
 Local $_TargetAdress = DllStructGetPtr($taStrPtr)
 Local $_SearchPattern = DllStructGetPtr($spStrPtr)
 Local $_SearchMask = DllStructGetPtr($smStrPtr)
 Local $_ReplacePattern = DllStructGetPtr($rpStrPtr)
 Local $_ReplaceMask = DllStructGetPtr($tmStrPtr)
 Local $_PatternSize = DllStructGetSize($rpStrPtr)
 Local $_SearchSize = DllStructGetSize($taStrPtr)
 Local $aRep = DllCall("SNR_PatchEngine.dll", 'BYTE', 'SearchAndReplace', 'DWORD', $_TargetAdress, 'DWORD', $_SearchPattern, 'DWORD', $_SearchMask, 'DWORD', $_ReplacePattern, 'DWORD', $_ReplaceMask, 'DWORD', $_PatternSize, 'DWORD', $_SearchSize, 'DWORD', -1)
 If @error Or (Not IsArray($aRep)) Then Return SetError(@error, 0, $oStringToSnR)
 If $IsBinary <> 0 Then Return SetError(@error, 4, Binary("0x" & $taStrPtr.Data))
 If $tReturn <> 0 Then Return SetError(@error, 2, "0x" & $taStrPtr.Data)
 Return SetError(@error, 1, $taStrPtr.Data)
EndFunc   ;==>_HexSearchAndReplace